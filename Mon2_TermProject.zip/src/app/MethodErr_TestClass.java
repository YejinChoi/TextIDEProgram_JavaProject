package app;

public class MethodErr_TestClass {
	public static void main(String [] args){
		Person p = new Person();
		p.Getname();
		System.out.println("HelloWorld");
	}

}


class Person{
	
}
