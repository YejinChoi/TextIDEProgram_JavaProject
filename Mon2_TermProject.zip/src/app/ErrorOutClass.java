package app;

import java.util.*;
import java.io.*;

public class ErrorOutClass {
	public static void ErrFilePrintFunc(String errfName) {

		LineNumberReader reader = null;

		try {

			reader = new LineNumberReader(new FileReader(new File(errfName)));

			String line = null;

			while ((line = reader.readLine()) != null) {

				System.out.println(line);

			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {
				if (reader != null)
					reader.close();
			} catch (IOException e) {
			}

		}

	}

}
