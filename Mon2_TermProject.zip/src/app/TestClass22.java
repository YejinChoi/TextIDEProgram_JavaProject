package app;

public class TestClass22 {
	public static void main(String[] args){
		System.out.println("What");
		int arr [] = new int[5]
		
		int c=0;
		
		for(int i=0;i<5;i++)
			System.out.print(arr[i]+"\t");
		
		System.out.println(");
	}
}
